
#ifndef HEADER_H
#define HEADER_H


#include <stdio.h>   
#include <stdlib.h> 
#include <string.h>  
#include <ctype.h>   


typedef enum
{
    failure,   // Operation failed
    success    // Operation successful
} Status;

// Structure for storing input file names (Singly linked list)
typedef struct Node
{
    char str[20];        // File name
    struct Node* link;  // Pointer to next node
} Slist;

// Structure for sub-node (file-wise word details)
typedef struct sub_node
{
    int word_count;        // Count of word in a file
    char file_name[20];   // File name
    struct sub_node* link;// Pointer to next sub-node
} S_node;

// Structure for main node (unique word entry)
typedef struct main_node
{
    int file_count;       // Number of files containing the word
    char word[50];        // Word stored
    S_node* S_link;       // Link to sub-node list
    struct main_node* M_link; // Link to next main node
} M_node;

// Hash table structure
typedef struct hash_table
{
    int index;       // Hash table index
    M_node *link;   // Pointer to main node chain
} Hash_t;


// Function to read and validate command-line arguments
Status read_and_validate(int argc, char* argv[], Slist **head);

// Function to insert file name at end of Slist
Status insert_at_last(Slist **head, char argv[]);

// Function to check duplicate file names
Status search_dulp_fname(Slist* head, char argv[]);

// Function to create the inverted index database
Status create_database(Slist *head , Hash_t *arr);

// Function to display database contents
Status display(Hash_t *arr);

// Function to search a word in database
Status search(Hash_t *arr);

// Function to save database to file
Status save_database(Hash_t *arr);

// Function to update database with new files
Status update_database(Slist **head, Hash_t *arr);

// Function to load database from file
Status load_database(FILE *fptr, Slist **head, Hash_t *arr);

#endif  // End of HEADER_H
