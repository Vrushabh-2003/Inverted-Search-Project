#include "header.h"  

void print(Slist *head)  // Function to print the linked list
{
    printf("Head -> ");  

    Slist *temp = head;  // Temporary pointer to traverse the list

    while (temp != NULL)  // Loop until end of list
    {
        printf("%s  ->", temp->str);  // Print each filename
        temp = temp->link;  // Move to next node
    }
    printf("NULL\n");  // Print end of list
}

Status read_and_validate(int argc, char *argv[], Slist **head)  // Validate input files
{
    int flag = 0;  // Status flag

    for (int i = 1; i < argc; i++)  // Traverse input arguments
    {
        if (strstr(argv[i], ".txt") == NULL)  // Check .txt extension
        {
            printf("The FILE:  %s is not having .txt extension\n", argv[i]);  // Print message
            continue;  // Skip to next input
        }

        FILE *fptr = fopen(argv[i], "r");  // Open file
        if (fptr == NULL)  // Check if file exists
        {
            printf("The file is not present %s\n", argv[i]);  // Error message
            continue;  // Skip current file
        }

        fseek(fptr, 0, SEEK_END);  // Move to end of file
        if (ftell(fptr) == failure)  // Check if file is empty
        {
            printf("The FILE:  %s is Empty\n", argv[i]);  // Print message
            continue;  // Skip file
        }

        if (search_dulp_fname(*head, argv[i]) == success)  // Check duplicate filenames
        {
            flag = 1;  // Set success status
            insert_at_last(head, argv[i]);  // Insert filename into list
        }
    }

    print(*head);  // Print validated file list

    if (flag == 1)  // If at least one file inserted
        return success;  // Return success
    else
        return failure;  // Return failure
}

Status insert_at_last(Slist **head, char argv[])  // Insert node at end of list
{
    Slist *new = malloc(sizeof(Slist));  // Allocate memory for new node

    strcpy(new->str, argv);  // Copy filename
    new->link = NULL;  // Initialize link

    if (new == NULL)  // Check allocation
        return failure;  // Return failure

    if (*head == NULL)  // If list empty
        *head = new;  // Assign new node as head

    else
    {
        Slist *temp = *head;  // Temporary pointer

        while (temp->link != NULL)  // Traverse to last node
            temp = temp->link;

        temp->link = new;  // Attach new node to end
    }

    return success;  // Return success
}

Status search_dulp_fname(Slist *head, char argv[])  // Check duplicate filenames
{
    if (head == NULL)  // If list blank
        return success;  // No duplicates

    while (head != NULL)  // Traverse list
    {
        if (strcmp(head->str, argv) == failure)  // Compare filenames
            return failure;  // Duplicate found

        head = head->link;  // Move to next node
    }

    return success;  // No duplicate found
}

Status upload_database(Slist *head, Hash_t *arr)  // Upload content to hash table
{
    FILE *fptr = fopen(head->str, "r");  // Open text file
    char ptr[50];  // Buffer for words

    while (fscanf(fptr, "%s", ptr) == 1)  // Read each word
    {
        char ch = ptr[0];  // Get first letter
        int index;  // Hash index

        if (ch >= 'A' && ch <= 'Z')  // Uppercase case
            index = ch - 65;  // Calculate index
        else if (ch >= 'a' && ch <= 'z')  // Lowercase case
            index = ch - 97;  // Calculate index
        else
            index = 26;  // Special character index

        if (arr[index].link == NULL)  // If empty bucket
        {
            M_node *mnode = malloc(sizeof(M_node));  // Allocate main node
            S_node *snode = malloc(sizeof(S_node));  // Allocate sub node

            mnode->file_count = 1;  // Initialize file count
            strcpy(mnode->word, ptr);  // Store word
            mnode->S_link = snode;  // Attach subnode
            mnode->M_link = NULL;  // Initialize main link

            snode->word_count = 1;  // Set word count
            strcpy(snode->file_name, head->str);  // Store filename
            snode->link = NULL;  // Initialize link

            if (mnode == NULL || snode == NULL)  // Allocation check
            {
                printf("The Node is not created in database\n");  // Error message
                return failure;  // Return failure
            }

            arr[index].link = mnode;  // Link main node to hash table
        }
        else
        {
            M_node *temp = arr[index].link;  // Traverse main list
            M_node *prev = arr[index].link;  // Save previous node
            int flag1 = 0;  // Word found flag

            while (temp != NULL)  // Traverse all words
            {
                prev = temp;  // Store previous node

                if (strcmp(ptr, temp->word) == 0)  // Word match
                {
                    int flag = 0;  // File found flag

                    S_node *subnode = temp->S_link;  // Subnode pointer
                    S_node *sub_prev_node = temp->S_link;  // Previous subnode

                    while (subnode != NULL)  // Traverse all files
                    {
                        sub_prev_node = subnode;  // Save previous

                        if (strcmp(head->str, subnode->file_name) == 0)  // File exists
                        {
                            flag = 1;  // Set found
                            subnode->word_count++;  // Increment word count
                            break;  // Exit loop
                        }

                        subnode = subnode->link;  // Next subnode
                    }

                    if (flag == 0)  // New file entry
                    {
                        S_node *snode = malloc(sizeof(S_node));  // Create subnode

                        snode->word_count = 1;  // Initialize count
                        strcpy(snode->file_name, head->str);  // Copy filename
                        snode->link = NULL;  // Init link

                        sub_prev_node->link = snode;  // Attach node
                        temp->file_count++;  // Increment file count
                    }

                    flag1 = 1;  // Mark word found
                }

                temp = temp->M_link;  // Move to next main node
            }

            if (flag1 == 0)  // New word entry
            {
                M_node *mnode = malloc(sizeof(M_node));  // Allocate main node
                S_node *snode = malloc(sizeof(S_node));  // Allocate subnode

                mnode->file_count = 1;  // Initialize
                strcpy(mnode->word, ptr);  // Store word
                mnode->S_link = snode;  // Attach subnode
                mnode->M_link = NULL;  // Init main link

                snode->word_count = 1;  // Initialize
                strcpy(snode->file_name, head->str);  // Store filename
                snode->link = NULL;  // Init link

                if (mnode == NULL || snode == NULL)  // Allocation check
                {
                    printf("The Node is not created in database\n");  // Error output
                    return failure;  // Failure
                }

                prev->M_link = mnode;  // Attach new word node
            }
        }
    }

    fclose(fptr);  // Close file
}

Status create_database(Slist *head, Hash_t *arr)  // Create database
{
    while (head != NULL)  // Loop through file list
    {
        upload_database(head, arr);  // Upload word data
        head = head->link;  // Next file
    }

    printf("Create database is Successfully Done\n");  // Success message
    return success;  // Return success
}

Status display(Hash_t *arr)  // Display database
{
    for (int i = 0; i < 27; i++)  // Loop buckets
    {
        M_node *temp = arr[i].link;  // Main node pointer

        if (temp == NULL)  // Skip empty bucket
            continue;

        while (temp != NULL)  // Traverse chain
        {
            printf("[%d]  [ %s ]  Files: %d", i, temp->word, temp->file_count);  // Print word info

            S_node *sub = temp->S_link;  // Subnode pointer
            while (sub != NULL)  // Traverse files
            {
                printf(", %s %d", sub->file_name, sub->word_count);  // Print details
                sub = sub->link;  // Next subnode
            }

            printf("\n");  // New line
            temp = temp->M_link;  // Next main node
        }
    }

    return success;  // Return success
}
