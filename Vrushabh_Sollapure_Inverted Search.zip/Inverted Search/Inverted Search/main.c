/*
NAME : Vrushabh Sollapure
DATE: 30/11/2025
DES: INVERTED SEARCH PROJECT
SAMPLE I/O:
    INPUT: ./a.out file1.txt file2.txt
    OUTPUT:  welcome to everyone $
             Vrushabh Sollapure $ $
*/
# include "header.h"  

int main(int argc, char* argv[])  
{
    if(argc == 1)  // Check if no file name is passed
    {
        printf("U have not entered any File name\n");  // Print error message
        return 0;  
    }
    Slist *head = NULL;  // Initialize linked list head
    Hash_t arr[27];  // Declare hash table array

    for (int i = 0; i < 27; i++)  // Initialize hash table
    {
        arr[i].link = NULL;  // Set all bucket links to NULL
    }

    int cflag = 1;  // Create database flag
    int dflag = 1;  // Display flag

    FILE *fptr = fopen("Database.txt", "r");  // Open backup database file
    if(fptr != NULL)  // If file exists
    {
        fseek(fptr, 0, SEEK_END);  // Go to end of file
        if(ftell(fptr) != failure)  // If file is not empty
        {
            rewind(fptr);  // Reset file pointer
            load_database(fptr,&head,arr);  // Load database from file
        }
        else
            dflag = 0;  // Set no data flag
    }

    if (read_and_validate(argc,argv,&head) == failure && dflag == 0)  // Validate input files
    {
        printf("All the Files are Not Proper\n");  // Validation failure message
        return 0;  // Exit program
    }

    while (1)  // Infinite menu loop
    {
        printf("\nSelect ur choice among this options :-\n");  // Menu header
        printf("1. Create Database\n2. Display Database\n3. Update database\n4. search\n5. Save database\n6. Exit\n");  // Options list

        int opt;  // User menu choice variable
        printf("Enter your choice:  ");  // Prompt user
        scanf("%d",&opt);  // Read user input

        switch (opt)  // Process user choice
        {
        case 1:  // Create database
            if(cflag == 1)  // If not already created
                create_database(head, arr);  // Create database
            else
                printf("create database is already created\n");  // Warning message

            cflag = 0;  // Reset create flag
            dflag = 2;  // Update display flag
            break;

        case 2:  // Display database
            if(dflag == 0)  // If database doesn't exist
            {
                printf("Create database 1st and then display the data \n");  // Error message
                break;
            }
            else if (dflag == 1)  // If backup file loaded
            {
                printf("Backup File Data Only Displayed Successfully\n");  // Info message
            }
            else
                printf("Backup File Data And Created Data both Displayed Successfully\n");  // Info message

                display(arr);  // Display database
            break;

        case 3:  // Update database
            update_database(&head,arr);  // Add new file and update DB
            break;

        case 4:  // Search word
            search(arr);  // Call search function
            break;

        case 5:  // Save database
            save_database(arr);  // Write database to file
            printf("The data Saved in 'Database.txt' Successfully\n");  // Confirmation message
            break;

        case 6:  // Exit program
            return failure;  // Exit with failure
            break;
        
        default:  // Invalid input
            printf("Invalid Choice\n");  // Print error message
            break;
        }
    }

}  // End of program
